#Windows Azure Active Directory Jwt Token Handler for .Net
===========

* Support for creating and validating Json Web Tokens.
* Provides model for config free validation using TokenValidationParameters.


##We will be working from a different repo going forward. We combined this work with additional Identity extensions to provide support for OpenIdConnect and WsFederation.
##Please use the following repo for any issues.

https://github.com/MSOpenTech/azure-activedirectory-identitymodel-extensions-for-dotnet/

## License

Copyright (c) Microsoft Open Technologies, Inc.  All rights reserved. Licensed under the Apache License, Version 2.0 (the "License");