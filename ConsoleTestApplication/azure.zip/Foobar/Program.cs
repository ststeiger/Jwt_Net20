﻿
using System.IO;
using System.Xml;

using System.IdentityModel.Tokens;
using System.IdentityModel.Selectors;
using System.IdentityModel.Protocols.WSTrust;

using Claim = System.Security.Claims.Claim;
using ClaimsIdentity = System.Security.Claims.ClaimsIdentity;
using ClaimTypes = System.Security.Claims.ClaimTypes;
using ClaimValueTypes = System.Security.Claims.ClaimValueTypes;


using System.IdentityModel.Test;



namespace Foobar
{


    static class Program
    {


        public static void RoundTripTokens()
        {
            JwtSecurityTokenHandler handler = new JwtSecurityTokenHandler();
            handler.CertificateValidator = X509CertificateValidator.None;


            System.Collections.Generic.List<string> ls = new System.Collections.Generic.List<string>();





            System.Collections.Generic.List<CreateAndValidateParams> ls2 = System.Linq.Enumerable.ToList(JwtTestTokens.All);
            System.Console.WriteLine(ls2.Count);


            foreach (CreateAndValidateParams jwtParams in JwtTestTokens.All)
            {
                System.Console.WriteLine("Validating streaming from JwtSecurityToken and TokenValidationParameters is same for Case: '" + jwtParams.Case);

                string jwt = handler.WriteToken(jwtParams.CompareTo);
                handler.ValidateToken(jwt, jwtParams.TokenValidationParameters);

                // create from security descriptor
                SecurityTokenDescriptor tokenDescriptor = new SecurityTokenDescriptor();
                tokenDescriptor.SigningCredentials = jwtParams.SigningCredentials;
                tokenDescriptor.Lifetime = new Lifetime(jwtParams.CompareTo.ValidFrom, jwtParams.CompareTo.ValidTo);
                tokenDescriptor.Subject = new ClaimsIdentity(jwtParams.Claims);
                tokenDescriptor.TokenIssuerName = jwtParams.CompareTo.Issuer;
                tokenDescriptor.AppliesToAddress = jwtParams.CompareTo.Audience;

                JwtSecurityToken token = handler.CreateToken(tokenDescriptor) as JwtSecurityToken;
                // Assert.IsFalse(!IdentityComparer.AreEqual(token, jwtParams.CompareTo), "!IdentityComparer.AreEqual( token, jwtParams.CompareTo )");

                // write as xml
                MemoryStream ms = new MemoryStream();
                XmlDictionaryWriter writer = XmlDictionaryWriter.CreateDictionaryWriter(XmlTextWriter.Create(ms));
                handler.WriteToken(writer, jwtParams.CompareTo);
                writer.Flush();
                ms.Flush();
                ms.Seek(0, SeekOrigin.Begin);
                XmlDictionaryReader reader = XmlDictionaryReader.CreateTextReader(ms, XmlDictionaryReaderQuotas.Max);
                reader.Read();
                handler.CertificateValidator = X509CertificateValidator.None;
                token = handler.ReadToken(reader) as JwtSecurityToken;
                ls.Add(token.ToString());


                ms.Close();
                // IdentityComparer.AreEqual(token, jwtParams.CompareTo);
            }


            string allTokens = string.Join(System.Environment.NewLine, ls.ToArray());
            System.Console.WriteLine(allTokens);
        }

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [System.STAThread]
        static void Main()
        {
            RoundTripTokens();
            
            System.Windows.Forms.Application.EnableVisualStyles();
            System.Windows.Forms.Application.SetCompatibleTextRenderingDefault(false);
            System.Windows.Forms.Application.Run(new Form1());
        }
    }
}
