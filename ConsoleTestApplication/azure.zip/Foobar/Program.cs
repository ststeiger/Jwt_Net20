﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;





using System.Globalization;
using System.Collections.Generic;
using System.IdentityModel.Protocols.WSTrust;
using System.IdentityModel.Selectors;
using System.IdentityModel.Tokens;
using System.IO;
using System.Reflection;
using System.Security.Claims;
using System.Xml;




using System.Collections.Generic;
using System.IdentityModel.Protocols.WSTrust;
using System.IdentityModel.Tokens;
using System.Web.Script.Serialization;

using Claim = System.Security.Claims.Claim;
using ClaimsIdentity = System.Security.Claims.ClaimsIdentity;
using ClaimTypes = System.Security.Claims.ClaimTypes;
using ClaimValueTypes = System.Security.Claims.ClaimValueTypes;


using System.IdentityModel.Test;



namespace Foobar
{
    static class Program
    {


        public static void RoundTripTokens()
        {
            JwtSecurityTokenHandler handler = new JwtSecurityTokenHandler();
            handler.CertificateValidator = X509CertificateValidator.None;

            foreach (CreateAndValidateParams jwtParams in JwtTestTokens.All)
            {
                Console.WriteLine("Validating streaming from JwtSecurityToken and TokenValidationParameters is same for Case: '" + jwtParams.Case);

                string jwt = handler.WriteToken(jwtParams.CompareTo);
                handler.ValidateToken(jwt, jwtParams.TokenValidationParameters);

                // create from security descriptor
                SecurityTokenDescriptor tokenDescriptor = new SecurityTokenDescriptor();
                tokenDescriptor.SigningCredentials = jwtParams.SigningCredentials;
                tokenDescriptor.Lifetime = new Lifetime(jwtParams.CompareTo.ValidFrom, jwtParams.CompareTo.ValidTo);
                tokenDescriptor.Subject = new ClaimsIdentity(jwtParams.Claims);
                tokenDescriptor.TokenIssuerName = jwtParams.CompareTo.Issuer;
                tokenDescriptor.AppliesToAddress = jwtParams.CompareTo.Audience;

                JwtSecurityToken token = handler.CreateToken(tokenDescriptor) as JwtSecurityToken;
                // Assert.IsFalse(!IdentityComparer.AreEqual(token, jwtParams.CompareTo), "!IdentityComparer.AreEqual( token, jwtParams.CompareTo )");

                // write as xml
                MemoryStream ms = new MemoryStream();
                XmlDictionaryWriter writer = XmlDictionaryWriter.CreateDictionaryWriter(XmlTextWriter.Create(ms));
                handler.WriteToken(writer, jwtParams.CompareTo);
                writer.Flush();
                ms.Flush();
                ms.Seek(0, SeekOrigin.Begin);
                XmlDictionaryReader reader = XmlDictionaryReader.CreateTextReader(ms, XmlDictionaryReaderQuotas.Max);
                reader.Read();
                handler.CertificateValidator = X509CertificateValidator.None;
                token = handler.ReadToken(reader) as JwtSecurityToken;
                ms.Close();
                // IdentityComparer.AreEqual(token, jwtParams.CompareTo);
            }
        }

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            RoundTripTokens();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
